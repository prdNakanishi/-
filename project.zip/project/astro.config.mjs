// @ts-check
import { defineConfig } from 'astro/config';
import relativeLinks from 'astro-relative-links';
// import { imagetools } from 'vite-imagetools';
// import { visualizer } from "rollup-plugin-visualizer";

// https://astro.build/config
export default defineConfig({
    base: '/tamatsukuri/',
    integrations: [relativeLinks()],
    
    outDir: '_public_html',
      
  output: 'static',
    build: {
    // format: "file",
      // format: 'file',
      // format: 'directory',
      assets: '_bundle',
      format: 'preserve',
  },
  vite: {
    // plugins: [imagetools()],
    esbuild: {
      drop: ["console", "debugger"], 
    },
    build: {
      // format: 'file',
      // format: 'directory',

      // format: 'preserve',
      // cssMinify: "esbuild", // デフォルトで CSS コメントも削除される
      // rollupOptions: {
      //   plugins: [
      //     visualizer({
      //       open: true, // ビルド後にブラウザで可視化ページを開く
      //       filename: "stats.html", // 出力されるファイル名（デフォルトは "stats.html"）
      //       gzipSize: true,
      //       brotliSize: true,
      //     }),
      //   ],
      // },
    },
  },
});
