import {commonFunctions} from "./common.js"
import Swiper from 'swiper/bundle'

window.addEventListener("load", (event) => {
  commonFunctions();
});

document.addEventListener('DOMContentLoaded', () => {
  const mySwiper = new Swiper('.swiper', {
    speed: 1000,
    loop: true,
    mousewheel: {
      forceToAxis: true,
      sensitivity: 3
    },
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
    slidesPerView: 'auto',
    spaceBetween: 20,
    centeredSlides: true,
    breakpoints: {
      751: {
        spaceBetween: 40,
      }
    },
    //pagination: {
    //  el: '.swiper-pagination',
    //  clickable: true
    //},
    navigation: {
      nextEl: '.swiper-btn-next',
      prevEl: '.swiper-btn-prev'
    },
  });
  mySwiper.autoplay.stop();
});