import {hamburgerMenu} from './modules/HamburgerMenu.js';
import AOS from 'aos';
import Lenis from 'lenis'
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

// common variable
let windowWid = window.innerWidth;
let border = 750; //閾値






// menuの開閉に関わる変数






function getOffsetTop(elem) {
	let offsetTop = 0;
	while (elem) {
		offsetTop += elem.offsetTop;
		elem = elem.offsetParent;
	}
	return offsetTop;
}

function logColor() {
	// console.log("checkLog");
	const targets = document.querySelectorAll(".checkLog");
	const classHolder = document.querySelector("#head");
	const showClass = "logoC";

	function checkAll() {
		let matched = false;

		for (const target of targets) {
			const contentTop = getOffsetTop(target);
			const contentBottom = contentTop + target.offsetHeight;

			const scrollTop = document.scrollingElement.scrollTop;
			const winHeight = window.innerHeight;
			const viewportMiddle = scrollTop + winHeight / 8;

			// console.log(`[${target.className}]`);
			console.log(`  contentTop: ${contentTop}`);
			// console.log(`  contentBottom: ${contentBottom}`);
			// console.log(`  scrollTop: ${scrollTop}`);
			// console.log(`  viewportMiddle: ${viewportMiddle}`);

			if (viewportMiddle >= contentTop && viewportMiddle <= contentBottom) {
				matched = true;
			}
		}

		if (matched) {
			// console.log("→ クラス追加: logoC");
			classHolder.classList.add(showClass);
		} else {
			// console.log("→ クラス削除: logoC");
			classHolder.classList.remove(showClass);
		}
	}

	// 初期チェック
	checkAll();

	// スクロールイベント
	window.addEventListener("scroll", checkAll);
}



function aosActive() {
	AOS.init({
		offset: 100,
		duration: 1000,
		easing: 'ease-out-cubic',
		once: true,
	});
}




let currentWid;

function getCurrentWid() {
	if(windowWid <= border) {
		return "sp"
	} else {
		return "pc"
	}
}
function currentWidInitalize() {
	currentWid = getCurrentWid();
	onChangeBorder();
}
currentWidInitalize();
window.addEventListener("resize", (event) => {
	windowWid = window.innerWidth;
	let preWid = currentWid;
	currentWid = getCurrentWid();
	if(preWid != currentWid) {
		onChangeBorder();
	}
});
function onChangeBorder() {
	windowWid = window.innerWidth;
	if (windowWid <= border) {
		
		// fixed_cv_btnBtnView("sp")
	} else {
		
		// fixed_cv_btnBtnView("pc")
	}
}


function zoomoutAnimation() {
	const triggers = document.querySelectorAll(".zoom_out-animation");
	if(triggers) {
		triggers.forEach( (element) => {
			const target = element.querySelector(".zoom_out-animation-target");
			ScrollTrigger.create({
				trigger: element, // 変更された変数名を使用
				start: () => `top bottom`,
				onEnter: () => {
        gsap.to(target, { scale: 1.0009, duration: 5, ease: "power4.out", });
      },
				// markers: true, 
			});
		});
	}
}


function headerLoad() {
	  // ヘッダー表示。最初から表示していると、画像読み込みの関係でaltが見えるため
  const header = document.querySelector("header");
  gsap.to(header, {
    opacity: 1,
    
    duration: 0.1, 
    delay: 0,// 0.5秒後にこのアニメーションを実行する
    // ease: "power2.inOut" // アニメーションのイージングを指定。これには様々な指定ができる
  });
}



// window.addEventListener("resize", ()=>{
// 	AOS.refresh();
// }, false);


let lenis;
export function initLenis() {
  // すでに初期化済みならスキップ
  if (lenis) return lenis;

  console.log("make lenis instance");
  lenis = new Lenis({
    autoRaf: true,
  });
  return lenis;
}

export function commonFunctions() {
	// console.log("aaa");
	hamburgerMenu();
	logColor();
	aosActive();
	headerLoad();
	console.log("make lenis instance")
	initLenis(); 
}
export function getLenis() {
  return lenis || initLenis();
}