import {commonFunctions} from "./common.js"
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { CustomEase } from "gsap/CustomEase";


import ScrollLockManager from './modules/ScrollLockManager.js';



const logoFadeTime = 1200;
const logoFadeAfterTime = 1100;
const logoFadeTotalTime = logoFadeTime + logoFadeAfterTime;
const kvAnimationStartTime = 1000;
function topKVAnimation() {
  animationProcess();
  // ScrollLockManager.unlockScroll();
}
function animationProcess() {
  // 初期処理
  const shots = document.querySelector(".shots");
  const kv = document.querySelector(".kv");
  if (shots) {
    shots.style.opacity = "1";
  }
  if (kv) {
    kv.style.opacity = "1";
  }

  // Fade Logo
  const logo = document.querySelector(".load .kvanim_img-relative_wrap .logo");
  gsap.to(logo, {
    opacity: 1,
    
    duration: logoFadeTime / 1000, // 1秒間かけて行う
    delay: 0.5,　// 0.5秒後にこのアニメーションを実行する
    // ease: "power2.inOut" // アニメーションのイージングを指定。これには様々な指定ができる
  });
  


  const shotsItems = shots.querySelectorAll(".kvanim_img-absolute_wrap");
  const kvItems = kv.querySelectorAll(".kvanim_img-absolute_wrap");
  const kvanimElements = Array.from(shotsItems).concat(Array.from(kvItems));
  console.log(kvanimElements);
  
  window.setTimeout(function(){
    ScrollLockManager.unlockScroll();
    const htmlDom = document.querySelector("html");
    htmlDom.classList.add("contentsVisible");
    const tl = gsap.timeline();

    tl.fromTo(kvanimElements, { //各画像を連続で表示
      opacity: 0,
    }, {
      opacity: 1,
      duration: 0.3,
      ease: "none",
      stagger: 0.5,
    })
    .fromTo(".kv .logo img", { //logo表示
      opacity: 0,
      scale: 1.06,
      filter: "blur(10px)",
    }, {
      filter: "blur(0px)",
      delay: 1,
      opacity: 1,
      scale: 1,
      duration: 2.2,
      ease: "power2.out",
      onStart: () => {
        // アニメーション開始と同時にクラス追加
        const captionTarget = document.querySelector(".kv .caption");
        console.log(captionTarget);
        captionTarget.classList.add("visible");
      }
    })
    // .fromTo(".kvanim_img-relative_wrap .scroll-icon", { //logo表示
    .fromTo(".kv_animation-wrap .scroll-wrap .scroll-icon", { //logo表示
      opacity: 0,
      transform: "translate(-50%, -50%) scale(1.06)",
      filter: "blur(10px)",
    }, {
      filter: "blur(0px)",
      opacity: 1,
      transform: "translate(-50%, -50%) scale(1)",
      duration: 1.0,
      ease: "power2.out"
    });

    //各画像を連続で表示,scaleのコントロール。durationをopacityと違うのを設定したかったのでここで別定義
    gsap.fromTo(kvanimElements, { 
      scale: 1.05
    }, {
      duration: 1, 
      scale: 1,
      ease: "power2.out", 
      stagger: 0.5, 
    });
    // kvanimElements.forEach( (element) => {

    // });
  }, logoFadeTotalTime);
}



function navMask() {
	window.setTimeout(function(){
    document.querySelector("header .menu").classList.add("visible");
	}, 400);
}


document.addEventListener("DOMContentLoaded", (event) => {
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  document.documentElement.scrollTop = 0;
  document.body.scrollTop = 0;
  ScrollLockManager.lockScroll();
});
window.addEventListener("load", (event) => {
  commonFunctions();
  topKVAnimation();
  // navMask();
});

