import {commonFunctions} from "./common.js"

window.addEventListener("load", (event) => {
  commonFunctions();
});

