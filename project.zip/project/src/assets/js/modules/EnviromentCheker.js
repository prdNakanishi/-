const EnvironmentChecker = (function () {
  let instance = null;

  class Checker {
    constructor() {
      this.browser = null;
      this.device = null;
      this.isiPhone = false;

      this.checkBrowser();
      this.checkDevice();
      this.applyBodyClass();
    }

    checkBrowser() {
      const ua = navigator.userAgent.toLowerCase();

      if (ua.includes("edg") || ua.includes("edge") || ua.includes("edga") || ua.includes("edgios")) {
        this.browser = "edg";
      } else if (ua.includes("opera") || ua.includes("opr")) {
        this.browser = "opera";
      } else if (ua.includes("samsungbrowser")) {
        this.browser = "samsung";
      } else if (ua.includes("ucbrowser")) {
        this.browser = "uc";
      } else if (ua.includes("chrome") || ua.includes("crios")) {
        this.browser = "chrome";
      } else if (ua.includes("firefox") || ua.includes("fxios")) {
        this.browser = "firefox";
      } else if (ua.includes("safari")) {
        this.browser = "safari";
      } else if (ua.includes("msie") || ua.includes("trident")) {
        this.browser = "ie";
      } else {
        this.browser = "other";
      }
    }

    isTablet() {
      const ua = navigator.userAgent.toLowerCase();
      return (
        ua.includes("ipad") ||
        (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) ||
        (ua.includes("android") && !ua.includes("mobile")) ||
        ua.includes("tablet") ||
        ua.includes("kindle") ||
        ua.includes("silk") ||
        ua.includes("playbook")
      );
    }

    checkDevice() {
      const ua = navigator.userAgent.toLowerCase();

      if (/iphone|ipod|android.*mobile|windows.*phone|blackberry.*mobile/i.test(ua)) {
        this.device = "sp";
      } else if (this.isTablet()) {
        this.device = "tablet";
      } else {
        this.device = "pc";
      }

      if (/iphone/.test(ua)) {
        this.isiPhone = true;
      }
    }

    applyBodyClass() {
      const body = document.body;

      if (this.device === "pc" && this.browser === "safari") {
        body.classList.add("env_pc_safari");
      }
      if (this.isiPhone && this.browser === "safari") {
        body.classList.add("env_sp_safari");
      }
      if (this.browser === "edg") {
        body.classList.add("edge");
      }
      if (this.browser === "firefox") {
        body.classList.add("firefoxProperty");
      }
    }
  }

  return {
    getInstance() {
      if (!instance) {
        instance = new Checker();
      }
      return instance;
    },
  };
})();

export default EnvironmentChecker;