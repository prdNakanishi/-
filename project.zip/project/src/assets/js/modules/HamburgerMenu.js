import ScrollLockManager from './ScrollLockManager.js';


export function hamburgerMenu() {
	let btn = document.querySelector('.humberger-btn');
	let menuIcon = document.querySelector('.menu_icon');
	let headerElm = document.querySelector('.fixHeaderinner-wrap');
	let htmlElm = document.querySelector('html');

  console.log("hamburgerMenu ");

	btn.addEventListener('click', function() {
		if (btn.classList.contains('menuBtnActive')) {
			closeFunc();
		} else {
			openFunc();
		}
	});

	function openFunc() {
		btn.classList.add("menuBtnActive");
		headerElm.classList.add("menuActive");
		htmlElm.classList.add("menuActiveOnHTML");
		window.setTimeout(function(){
			ScrollLockManager.lockScroll();
		}, 300);
		// closeFixedCv("mainmenu");
	}

	function closeFunc() {
		if (menuIcon.classList.contains('hover')) {
			menuIcon.classList.remove("hover");
		}
		btn.classList.remove("menuBtnActive");
		headerElm.classList.remove("menuActive");
		htmlElm.classList.remove("menuActiveOnHTML");

		htmlElm.classList.add("navCloseScroll");
		setTimeout(() => {
			htmlElm.classList.remove("navCloseScroll");
		}, 500);

		ScrollLockManager.unlockScroll(); // ← スクロールを戻す
	}

	const menu = document.querySelector('.menu');
	const menuWrap = document.querySelector('.menuWrap');
	
	menu.addEventListener('click', function(e) {
		// メニュー本体（menuWrap）をクリックした場合は何もしない
		if (menuWrap.contains(e.target)) {
			// console.log("menuWrap内クリック → 何もしない");
			return;
		}
	
		// menuWrap以外（例えばマスクなど）をクリックした場合は閉じる
		// console.log("menuWrap外クリック → メニューを閉じる");
		closeFunc(); // ここでメニューを閉じる処理
	});
}