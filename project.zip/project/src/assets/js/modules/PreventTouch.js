export function preventTouch(e) {
  e.preventDefault();
}