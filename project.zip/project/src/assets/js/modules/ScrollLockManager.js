import {preventTouch} from './PreventTouch.js';
import {getLenis} from '../common.js';

// let isScrollLocked = false;

const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;

const ScrollLockManager = {
  isScrollLocked: false,
  scrollY: 0,
  scrollbarWidth: window.innerWidth - document.documentElement.clientWidth,
  lockScroll() {
    // if (this.isScrollLocked) return;

    // this.scrollY = window.scrollY;

    // // scroll lock
    // document.documentElement.style.overflow = 'hidden';
    // document.body.style.overflow = 'hidden';

    // // optional: prevent layout shift from scrollbar
    // document.body.style.paddingRight = `${scrollbarWidth}px`;

    // // iOS 対策
    // document.addEventListener('touchmove', preventTouch, { passive: false });

    const lenis = getLenis();
    this.isScrollLocked = true;
    // // console.log("🔒 Scroll locked");
      lenis.stop();
  },
  unlockScroll() {
    if (!this.isScrollLocked) return;

    // document.documentElement.style.overflow = '';
    // document.body.style.overflow = '';
    // document.body.style.paddingRight = '';

    // document.removeEventListener('touchmove', preventTouch);

    // // 一応 scrollY 保持してた場合の再設定（fixedじゃないのでたぶん不要だけど保険）
    // window.scrollTo(0, this.scrollY);
    const lenis = getLenis();
    lenis.start();
    this.isScrollLocked = false;
    // console.log("🔓 Scroll unlocked");
  }
}

export default ScrollLockManager;