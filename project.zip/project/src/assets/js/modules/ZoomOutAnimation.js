import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

export function zoomOutAnimation(target) {
  const animationTarget = target.querySelector("img");
    gsap.to(animationTarget, {
    scrollTrigger: {
      trigger: target,
      start: "top bottom",
      onEnter: () => {
        playAnimation(animationTarget);
      },
    }
  })
}

  function playAnimation(target) {
    console.log("target");
    console.log(target);

    gsap.fromTo(target, {
      scale: 1.1, 
      duration: 0,
    }, {
      scale: 1,
      duration: 6,
      ease: "sine.out",
    });
  }